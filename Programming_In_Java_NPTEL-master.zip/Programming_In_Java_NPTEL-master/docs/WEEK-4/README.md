# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)

## [WEEK 4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-4)

  [Java Week 4:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question41.java) To execute the following program successfully. You should import the correct package(s) and/or class(s) to complete the code.
  
  [Java Week 4:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question42.java) To print the current year. 
  
  [Java Week 4:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question43.java) The program in this assignment is attempted to print the following output: 
  
 -----------------OUTPUT-------------------
   
 This is large

 This is medium

 This is small

 This is extra-large

-----------------OUTPUT-------------------
  
  [Java Week 4:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question44.java)  To call the default method in the interface First and Second.

  [Java Week 4:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question45.java)  To print the following output.

-----------------OUTPUT-------------------

Circle: This is Shape1

Circle: This is Shape2

-----------------OUTPUT--------------------

