# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)

## [WEEK 3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-3)

  [Java Week 3:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Fibonacci.java) To the generation of Fibonacci numbers.

  [Java Week 3:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Circle.java) Define a class Point with two fields x and y each of type double. Also , define a method distance(Point p1, Point p2) to calculate the distance between points p1 and p2 and return the value in double. Complete the code segment given below. Use Math.sqrt( ) to calculate the square root.

  [Java Week 3:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Test1.java) A class Shape is defined with two overloading constructors in it. Another class Test1 is partially defined which inherits the class Shape. The class Test1 should include two overloading constructors as appropriate for some object instantiation shown in main( ) method. You should define the constructors using the super class constructors. Also, override the method calculate( ) in Test1 to calculate the volume of a Shape.

  [Java Week 3:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Test3.java) This program to exercise the call of static and non-static methods. A partial code is given defining two methods, namely sum( ) and multiply ( ). You have to call these methods to find the sum and product of two numbers.

  [Java Week 3:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Question3.java) To swap two numbers using call by object reference.
