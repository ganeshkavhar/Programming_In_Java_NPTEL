# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)


## [WEEK 5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-5)

  [Java Week 5:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-5/Question5_1.java)
  An interface Number is defined in the following program.  You have to declare a class A, which will implement the interface Number. Note that the method findSqr(n) will return the square of the number n.
  
  [Java Week 5:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-5/Question5_2.java)
  This program is to find the GCD (greatest common divisor) of two integers writing a recursive function findGCD(n1,n2). Your function should return -1, if the argument(s) is(are) other than positive number(s).
  
  [Java Week 5:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-5/Question5_3.java)
  Complete the code segment to catch the ArithmeticException in the following, if any. On the occurrence of such an exception, your program should print “Exception caught: Division by zero.” If there is no such exception, it will print the result of division operation on two integer values.
  
  [Java Week 5:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-5/Question5_4.java)
  In the following program, an array of integer data to be initialized. During the initialization, if a user enters a value other than integer value, then it will throw InputMismatchException exception. On the occurrence of such an exception, your program should print “You entered bad data.” If there is no such exception it will print the total sum of the array.

  [Java Week 5:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-5/Question5_5.java)
  In the following program, there may be multiple exceptions. You have to complete the code using only one try-catch block to handle all the possible exceptions.

For example, if user’s input is 1, then it will throw and catch “java.lang.NullPointerException“.
