# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)


## [WEEK 6](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-6)

  [Java Week 6:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-6/Question61.java)
  Complete the code segment to print the following using the concept of extending the Thread class in Java:

-----------------OUTPUT-------------------

Thread is Running.


  [Java Week 6:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-6/Question62.java)
  In the following program, a thread class ThreadRun is created using the Runnable interface which prints "Thread using Runnable interface". Complete the main class to create a thread object of the class ThreadRun and run the thread,
  
  [Java Week 6:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-6/Question63.java)
  A part of the Java program is given, which can be completed in many ways, for example using the concept of thread, etc.  Follow the given code and complete the program so that your program prints the message "NPTEL Java". Your program should utilize the given interface/ class.
  
  [Java Week 6:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-6/Question64.java)
  Execution of two or more threads occurs in a random order. The keyword 'synchronized' in Java is used to control the execution of thread in a strict sequence. In the following, the program is expected to print some numbers. Do the necessary use of 'synchronized' keyword, so that, the program prints the output in the following order:
  
-----------------OUTPUT-------------------

5

10

15

20

25

100

200

300

400

500


  [Java Week 6:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-6/Question65.java)
  Add necessary codes to print the following:
  
-----------------OUTPUT-------------------

Name of thread 't':Thread-0

New name of thread 't':NPTEL

Thread is running.
