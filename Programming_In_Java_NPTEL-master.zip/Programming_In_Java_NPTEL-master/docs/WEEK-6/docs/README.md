# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)


## [WEEK 1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-1)

  [Java Week 1:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_1.java) To find the perimeter and area of a circle given a value of radius.

  [Java Week 1:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_2.java) To find the largest among three numbers x, y, and z.

  [Java Week 1:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_3.java) Consider First n even numbers starting from zero(0) and calculate sum of  all the numbers divisible by 3 from 0 to n. Print the sum.

  [Java Week 1:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_4.java) To check whether the number is an Armstrong number or not.

  [Java Week 1:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_5.java) To help Ram , find the highest mark and average mark secured by him in "s" number of subjects.


## [WEEK 2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-2)

  [Java Week 2:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question211.java) To call the method  print() in class Student following the concept of inner class.

   [Java Week 2:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question212.java) To call the method  print() of class Student first and then call print() method of class School.

  [Java Week 2:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question213.java) To call print() method of class Question by creating a method named ‘studentMethod()’.

  [Java Week 2:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question214.java) To call default constructor first and then any other constructor in the class Answer.

  [Java Week 2:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question215.java) To debug the program which is intended to print 'NPTEL JAVA'.


## [WEEK 3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-3)

  [Java Week 3:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Fibonacci.java) To the generation of Fibonacci numbers.

  [Java Week 3:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Circle.java) Define a class Point with two fields x and y each of type double. Also , define a method distance(Point p1, Point p2) to calculate the distance between points p1 and p2 and return the value in double. Complete the code segment given below. Use Math.sqrt( ) to calculate the square root.

  [Java Week 3:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Test1.java) A class Shape is defined with two overloading constructors in it. Another class Test1 is partially defined which inherits the class Shape. The class Test1 should include two overloading constructors as appropriate for some object instantiation shown in main( ) method. You should define the constructors using the super class constructors. Also, override the method calculate( ) in Test1 to calculate the volume of a Shape.

  [Java Week 3:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Test3.java) This program to exercise the call of static and non-static methods. A partial code is given defining two methods, namely sum( ) and multiply ( ). You have to call these methods to find the sum and product of two numbers.

  [Java Week 3:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-3/Question3.java) To swap two numbers using call by object reference.


## [WEEK 4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-4)

  [Java Week 4:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question41.java) To execute the following program successfully. You should import the correct package(s) and/or class(s) to complete the code.
  
  [Java Week 4:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question42.java) To print the current year. 
  
  [Java Week 4:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question43.java) The program in this assignment is attempted to print the following output: 
  
 -----------------OUTPUT-------------------
   
 This is large

 This is medium

 This is small

 This is extra-large

-----------------OUTPUT-------------------
  
  [Java Week 4:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question44.java)  To call the default method in the interface First and Second.

  [Java Week 4:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-4/Question45.java)  To print the following output.

-----------------OUTPUT-------------------

Circle: This is Shape1

Circle: This is Shape2

-----------------OUTPUT--------------------


## [WEEK 5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-1)

## [WEEK 6](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-1)

## [WEEK 7](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-1)

## [WEEK 8](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-1) 
