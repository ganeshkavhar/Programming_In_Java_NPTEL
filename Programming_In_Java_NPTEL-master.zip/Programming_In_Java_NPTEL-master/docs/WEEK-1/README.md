# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)

## [WEEK 1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-1)

  [Java Week 1:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_1.java) To find the perimeter and area of a circle given a value of radius.

  [Java Week 1:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_2.java) To find the largest among three numbers x, y, and z.

  [Java Week 1:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_3.java) Consider First n even numbers starting from zero(0) and calculate sum of  all the numbers divisible by 3 from 0 to n. Print the sum.

  [Java Week 1:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_4.java) To check whether the number is an Armstrong number or not.

  [Java Week 1:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-1/Exercise1_5.java) To help Ram , find the highest mark and average mark secured by him in "s" number of subjects.
