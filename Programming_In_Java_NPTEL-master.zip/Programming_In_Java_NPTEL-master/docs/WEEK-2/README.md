# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)

## [WEEK 2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-2)

  [Java Week 2:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question211.java) To call the method  print() in class Student following the concept of inner class.

   [Java Week 2:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question212.java) To call the method  print() of class Student first and then call print() method of class School.

  [Java Week 2:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question213.java) To call print() method of class Question by creating a method named ‘studentMethod()’.

  [Java Week 2:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question214.java) To call default constructor first and then any other constructor in the class Answer.

  [Java Week 2:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-2/Question215.java) To debug the program which is intended to print 'NPTEL JAVA'.
