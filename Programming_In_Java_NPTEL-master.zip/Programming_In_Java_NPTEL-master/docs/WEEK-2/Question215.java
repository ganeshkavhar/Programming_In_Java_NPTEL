public class Question215{ 
    public static void main(String[] args) { 
	//Declare variable with name 'nptel', 'space' and 'java' and proper datatype.
	String nptel,space,java;
	//Initialize the variables with proper input
	nptel="NPTEL";
	space=" ";
	java="JAVA";
     	System.out.print(nptel+space+java);
   }
}