# [Programming_In_Java_NPTEL](https://github.com/bkkothari2255/Programming_In_Java_NPTEL)


## [WEEK 7](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/tree/WEEK-7)

  [Java Week 7:Q1](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-7/Question1.java) Complete the following code fragment to read three integer values from the keyboard and find the sum of the values. Declare a variable "sum" of type int and store the result in it.
  
  [Java Week 7:Q2](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-7/Question2.java) Complete the code segment to catch the exception in the following, if any. On the occurrence of such an exception, your program should print “Please enter valid data” .If there is no such exception, it will print the "square of the number".
  
  [Java Week 7:Q3](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-7/Question3.java) A byte char array is initialized. You have to enter an index value"n". According to index your program will print the byte and its corresponding char value.
Complete the code segment to catch the exception in the following, if any. On the occurrence of such an exception, your program should print “exception occur” .If there is no such exception, it will print the required output.
  
  [Java Week 7:Q4](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-7/Question4.java) The following program reads a string from the keyboard and is stored in the String variable "s1". You have to complete the program so that it should should print the number of vowels in s1 . If your input data doesn't have any vowel it will print "0".

  [Java Week 7:Q5](https://github.com/bkkothari2255/Programming_In_Java_NPTEL/blob/WEEK-7/Question5.java) A string "s1" is already initialized. You have to read the index "n"  from the keyboard. Complete the code segment to catch the exception in the following, if any. On the occurrence of such an exception, your program should print “exception occur” .If there is no such exception, your program should replace the char "a" at the index value "n" of the "s1" ,then it will print the modified string.
